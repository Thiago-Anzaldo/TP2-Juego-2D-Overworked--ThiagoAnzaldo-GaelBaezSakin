﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace _1;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;

    private Texture2D _spriteActual;

    private Texture2D _spriteTras;
    private Texture2D _spriteFront;
    private Texture2D _spriteIzq;
    private Texture2D _spriteDer;

    private float x = 0;
    private float y = 0;
    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        _spriteTras = Content.Load<Texture2D>("vistaTrasera");
        _spriteFront = Content.Load<Texture2D>("vistaFrontal");
        _spriteDer = Content.Load<Texture2D>("vistaDer");
        _spriteIzq = Content.Load<Texture2D>("vistaIzq");

        _spriteActual=_spriteFront;
        // TODO: use this.Content to load your game content here
    }

    protected override void Update(GameTime gameTime)
    {

        KeyboardState keyboardState = Keyboard.GetState();

        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        if (keyboardState.IsKeyDown(Keys.S))
        {
            // _spriteBatch.End();
            // _spriteBatch.Begin();
            y += 3.5f;
            _spriteActual = _spriteFront;
            // _spriteBatch.Draw(_illoJuan, new Vector2(x, y), Color.White);
        }
        if (keyboardState.IsKeyDown(Keys.W))
        {
            // _spriteBatch.End();
            // _spriteBatch.Begin();
            y -= 3.5f;
            _spriteActual = _spriteTras;
            // _spriteBatch.Draw(_illoJuan, new Vector2(x, y), Color.White);
        }
        if (keyboardState.IsKeyDown(Keys.A))
        {
            // _spriteBatch.End();
            // _spriteBatch.Begin();
            x -= 3.5f;
            _spriteActual = _spriteIzq;
            // _spriteBatch.Draw(_illoJuan, new Vector2(x, y), Color.White);
        }
        if (keyboardState.IsKeyDown(Keys.D))
        {
            // _spriteBatch.End();
            // _spriteBatch.Begin();
            x += 3.5f;
            _spriteActual = _spriteDer;
            // _spriteBatch.Draw(_illoJuan, new Vector2(x, y), Color.White);
        }
        // TODO: Add your update logic here

        base.Update(gameTime);
    }

protected override void Draw(GameTime gameTime)
{
    GraphicsDevice.Clear(Color.CornflowerBlue);

    // FIX: Activamos el filtro 'PointClamp' para mantener los píxeles perfectos y definidos
    _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);

    _spriteBatch.Draw(_spriteActual, new Vector2((int)x, (int)y), Color.White);

    _spriteBatch.End();

    base.Draw(gameTime);
}
}
