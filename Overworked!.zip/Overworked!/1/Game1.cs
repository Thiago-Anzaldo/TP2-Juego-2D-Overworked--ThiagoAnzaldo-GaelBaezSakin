﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace _1;

public class Game1 : Game
{
    private Texture2D _backgroundTexture;
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;

    private Texture2D _spriteAtlas;

    // Configuración del Atlas (Asumiendo que la imagen mide 640x640 y cada cuadro es de 213x213 aprox.)
    // AJUSTA ESTOS DOS NÚMEROS si el tamaño real de un solo muñeco en píxeles es diferente
    private int _spriteAncho = 213; 
    private int _spriteAlto = 213;

    // Variables de control de animación
    private int _frameActual = 0;
    private double _tiempoPorFrame = 0.15; // Velocidad de la animación (0.15 segundos por paso)
    private double _cronometroAnimacion = 0;
    private bool _estaCaminando = false;  // Activa esto solo cuando presiones teclas de movimiento
    private Matrix _cameraTransform;

    private float x = 0;
    private float y = 0;
    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        _spriteAtlas = Content.Load<Texture2D>("spritesCaminar");
        // TODO: use this.Content to load your game content here

        _spriteBatch = new SpriteBatch(GraphicsDevice);

        // Carga la imagen desde el Pipeline de Contenido
        _backgroundTexture = Content.Load<Texture2D>("mapa1-oficina");

    }
        

    protected override void Update(GameTime gameTime)
    {

        KeyboardState keyboardState = Keyboard.GetState();

    if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || keyboardState.IsKeyDown(Keys.Escape))
        Exit();

    // Por defecto asumimos que el pibe está quieto en este frame
    _estaCaminando = false;

    // Control de movimiento
    if (keyboardState.IsKeyDown(Keys.S))
    {
        y += 3.5f;
        _estaCaminando = true;
    }
    if (keyboardState.IsKeyDown(Keys.W))
    {
        y -= 3.5f;
        _estaCaminando = true;
    }
    if (keyboardState.IsKeyDown(Keys.A))
    {
        x -= 3.5f;
        _estaCaminando = true;
    }
    if (keyboardState.IsKeyDown(Keys.D))
    {
        x += 3.5f;
        _estaCaminando = true;
    }

    // CONTROL DE LA ANIMACIÓN
    if (_estaCaminando)
    {
        // Sumamos el tiempo transcurrido al cronómetro
        _cronometroAnimacion += gameTime.ElapsedGameTime.TotalSeconds;

        if (_cronometroAnimacion >= _tiempoPorFrame)
        {
            _cronometroAnimacion = 0;
            // Va pasando por los cuadros del atlas: 0 -> 1 -> 2 y vuelve a 0
            _frameActual = (_frameActual + 1) % 3;
        }
    }
    else
    {
        // Si no se mueve, lo dejamos en el frame 1 (el que tiene los pies juntos)
        _frameActual = 1;
        _cronometroAnimacion = 0;
    }

    // CENTRAR CÁMARA
    float cameraX = -x + (GraphicsDevice.Viewport.Width / 2f);
    float cameraY = -y + (GraphicsDevice.Viewport.Height / 2f);
    _cameraTransform = Matrix.CreateTranslation(cameraX, cameraY, 0);

    base.Update(gameTime);
    }

protected override void Draw(GameTime gameTime)
{
    GraphicsDevice.Clear(Color.Gray);

    _spriteBatch.Begin(
        SpriteSortMode.Deferred, 
        BlendState.AlphaBlend, 
        SamplerState.PointClamp, 
        null, 
        null, 
        null, 
        _cameraTransform
    );

    // DIBUJAR EL MAPA / FONDO
    float escalaFondo = 3.8f;
    Vector2 centroFondo = new Vector2(_backgroundTexture.Width / 2f, _backgroundTexture.Height / 2f);
    _spriteBatch.Draw(_backgroundTexture, Vector2.Zero, null, Color.White, 0f, centroFondo, escalaFondo, SpriteEffects.None, 0f);

    // ==========================================
    // CÁLCULO DEL RECORTE DEL ATLAS DEL PIBE
    // ==========================================
    int origenX = 0;
    int origenY = 0;

    // Calculamos las coordenadas según el frame usando tus variables de ancho y alto
    if (_frameActual == 0)
    {
        origenX = 0;
        origenY = 0;
    }
    else if (_frameActual == 1)
    {
        origenX = _spriteAncho; // Segunda columna
        origenY = 0;
    }
    else if (_frameActual == 2)
    {
        origenX = 0;
        origenY = _spriteAlto;  // Segunda fila
    }

    // Creamos el rectángulo con las dimensiones exactas que definiste
    Rectangle cuadroRecorte = new Rectangle(origenX, origenY, _spriteAncho, _spriteAlto);

    // Centramos el pivote basándonos en tus variables de tamaño
    Vector2 centroPersonaje = new Vector2(_spriteAncho / 2f, _spriteAlto / 2f);
    Vector2 posicionPersonaje = new Vector2((int)x, (int)y);

    // Dibujamos el cuadro recortado de tu '_spriteAtlas'
    _spriteBatch.Draw(
        _spriteAtlas,
        posicionPersonaje,
        cuadroRecorte,
        Color.White,
        0f,
        centroPersonaje,
        0.8f, // Escala del personaje (puedes subirlo a 1.5f o 2f si queda muy chico)
        SpriteEffects.None,
        0f
    );

    _spriteBatch.End();

    base.Draw(gameTime);
    }
}
